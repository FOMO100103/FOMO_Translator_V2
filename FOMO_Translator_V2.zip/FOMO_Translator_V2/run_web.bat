@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Please run install.bat first.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m streamlit run web_app\app.py
pause
